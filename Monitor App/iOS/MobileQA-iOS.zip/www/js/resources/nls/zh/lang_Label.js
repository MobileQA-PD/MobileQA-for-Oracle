define({
    "MCSInfo": "MCS",
    "Storage": "存储",
    "CustomAPI": "自定义API",
    "Analytics": "分析",
    "dialog": {
        "okay": "好的",
        "cancel": "取消"
    },
    "button": {
        "ok": "OK",
        "cancel": "Cancel",
        "login": "Login"
    },
    "companyName": "Oracle",
    "appName": "Mobile QoS"    
});
