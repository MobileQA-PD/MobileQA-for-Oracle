//
//  CrashReport.h
//  CrashReportLib
//
//  Created by 이승우 on 2016. 11. 6..
//  Copyright © 2016년 이승우. All rights reserved.
//

#import "CrashReportLib.h"

#import <Foundation/Foundation.h>
#import <UIKit/UIDevice.h>
#import <execinfo.h>
#import <iostream>
#import <fstream>
#import <time.h>

#define LOG_BUFFER_SIZE (1024*128)

namespace PEOPLE_AND_DREAM {
    
    inline std::string NSStringToString(NSString* str)
    {
        char szLog[LOG_BUFFER_SIZE] = { 0, };
        @try
        {
            [str getCString:szLog maxLength:sizeof(szLog)-1 encoding:NSUTF8StringEncoding];
        }
        @catch (NSException *exception)
        {
            NSLog(@"%@", exception.description);
        }
        return szLog;
    }
    
    inline void LogToFile(const char* log, const char* path)
    {
        try
        {
            static std::ofstream output;
            if ( false == output.is_open() )
            {
                output.open(path);
            }
            
            if ( true == output.good() )
            {
                output << log;
            }
            
            output.close();
        }
        catch(...)
        {
            NSLog(@"%s excepted", __FUNCTION__);
        }
    }
    
    
    inline void LogToFile(NSString* log, NSString* path)
    {
        PEOPLE_AND_DREAM::LogToFile(PEOPLE_AND_DREAM::NSStringToString(log).c_str(),
                                    (PEOPLE_AND_DREAM::NSStringToString(path).c_str()));
    }
}

void uncaughtExceptionHandler(NSException *exception);

@interface CrashReport : NSObject

NSString* makeJsonString(NSString *description, NSString *callstack);

+ (void)setCrashReport;
+ (void)setUserId : (NSString *)userId;
- (NSString *)makeJsonString : (NSString *)description : (NSString *)callstack;
- (void)sendReport : (BOOL)isSync;
//- (NSString*) unescape:(NSString*) string;
@end
