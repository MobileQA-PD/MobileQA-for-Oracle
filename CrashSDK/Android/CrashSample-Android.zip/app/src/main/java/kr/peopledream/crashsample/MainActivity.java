package kr.peopledream.crashsample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import kr.peopledream.crashlibrary.CrashCatchForAndroid;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CrashCatchForAndroid.Initialize(this);
        CrashCatchForAndroid.setUserId("test@user.id");


        throw new RuntimeException();
    }
}
